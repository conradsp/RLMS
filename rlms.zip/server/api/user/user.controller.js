'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.index = index;
exports.sortedIndex = sortedIndex;
exports.updateUser = updateUser;
exports.usersApproval = usersApproval;
exports.create = create;
exports.show = show;
exports.getAdmin = getAdmin;
exports.destroy = destroy;
exports.changePassword = changePassword;
exports.me = me;
exports.addBid = addBid;
exports.deleteBid = deleteBid;
exports.addWatch = addWatch;
exports.deleteWatch = deleteWatch;
exports.getBids = getBids;
exports.getWatches = getWatches;
exports.getMessages = getMessages;
exports.addMessage = addMessage;
exports.updateMessage = updateMessage;
exports.deleteMessage = deleteMessage;
exports.changestatus = changestatus;
exports.authCallback = authCallback;

var _user = require('./user.model');

var _user2 = _interopRequireDefault(_user);

var _passport = require('passport');

var _passport2 = _interopRequireDefault(_passport);

var _environment = require('../../config/environment');

var _environment2 = _interopRequireDefault(_environment);

var _jsonwebtoken = require('jsonwebtoken');

var _jsonwebtoken2 = _interopRequireDefault(_jsonwebtoken);

var _lodash = require('lodash');

var _lodash2 = _interopRequireDefault(_lodash);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function validationError(res, statusCode) {
  statusCode = statusCode || 422;
  return function (err) {
    res.status(statusCode).json(err);
  };
}

function handleError(res, statusCode) {
  statusCode = statusCode || 500;
  return function (err) {
    res.status(statusCode).send(err);
  };
}

/**
 * Get list of users
 * restriction: 'admin'
 */
function index(req, res) {
  return _user2.default.find({}, '-salt -password').exec().then(function (users) {
    return res.status(200).json(users);
  }).catch(handleError(res));
}

function sortedIndex(req, res) {
  if (req.body.search != null) {
    var searchString = req.body.search;
    return _user2.default.find({ '$or': [{ 'username': { '$regex': searchString, '$options': 'i' } }, { 'fullname': { '$regex': searchString, '$options': 'i' } }, { 'status': { '$regex': searchString, '$options': 'i' } }, { 'province': { '$regex': searchString, '$options': 'i' } }, { 'farmname': { '$regex': searchString, '$options': 'i' } }] }).select('username fullname status province district farmname').exec().then(respondWithResult(res)).catch(handleError(res));
  }
}

function saveUpdates(updates) {
  return function (entity) {
    var updated = _lodash2.default.merge(entity, updates);
    return updated.save().then(function (updated) {
      return updated;
    });
  };
}

// Updates an existing User in the DB
function updateUser(req, res) {
  if (req.body._id) {
    delete req.body._id;
  }
  return _user2.default.findById(req.params.id).exec().then(handleEntityNotFound(res)).then(saveUpdates(req.body)).then(respondWithResult(res)).catch(handleError(res));
}

// Gets a list of Users needing approval
function usersApproval(req, res) {
  return _user2.default.find({ 'status': 'New' }).exec().then(respondWithResult(res)).catch(handleError(res));
}

function doStatusChange(updates) {
  return function (entity) {
    entity.status = updates.status;
    return entity.save().then(function (entity) {
      return entity;
    });
  };
}

/**
 * Creates a new user
 */
function create(req, res, next) {
  var newUser = new _user2.default(req.body);
  newUser.provider = 'local';
  newUser.role = 'user';
  newUser.save().then(function (user) {
    var token = _jsonwebtoken2.default.sign({ _id: user._id }, _environment2.default.secrets.session, {
      expiresIn: 60 * 60 * 5
    });
    res.json({ token: token });
  }).catch(validationError(res));
}

/**
 * Get a single user
 */
function show(req, res, next) {
  var userId = req.params.id;

  return _user2.default.findById(req.params.id).exec().then(handleEntityNotFound(res)).then(respondWithResult(res)).catch(handleError(res));
}

function getAdmin(req, res) {

  return _user2.default.find({ 'role': 'admin' }, '-salt -password').exec().then(function (users) {
    return res.status(200).json(users);
  }).catch(handleError(res));
}

/**
 * Deletes a user
 * restriction: 'admin'
 */
function destroy(req, res) {
  return _user2.default.findByIdAndRemove(req.params.id).exec().then(function () {
    return res.status(200).end();
  }).catch(handleError(res));
}

/**
 * Change a users password
 */
function changePassword(req, res, next) {
  var userId = req.user._id;
  var oldPass = String(req.body.oldPassword);
  var newPass = String(req.body.newPassword);

  return _user2.default.findById(userId).exec().then(function (user) {
    if (user.authenticate(oldPass)) {
      user.password = newPass;
      return user.save().then(function () {
        res.status(204).end();
      }).catch(validationError(res));
    } else {
      return res.status(403).end();
    }
  });
}

function handleEntityNotFound(res) {
  return function (entity) {
    if (!entity) {
      res.status(404).end();
      return null;
    }
    return entity;
  };
}

function respondWithResult(res, statusCode) {
  statusCode = statusCode || 200;
  return function (entity) {
    if (entity) {
      return res.status(statusCode).json(entity);
    }
  };
}

/**
 * Get my info
 */
function me(req, res, next) {
  var userId = req.user._id;

  return _user2.default.findOne({ _id: userId }, '-salt -password').exec().then(function (user) {
    // don't ever give out the password or salt
    if (!user) {
      return res.status(401).end();
    }
    return res.json(user);
  }).catch(function (err) {
    return next(err);
  });
}

function addBid(req, res) {
  return _user2.default.update({ "_id": req.params.id }, { $addToSet: { "bids": req.body } }).exec().then(handleEntityNotFound(res)).then(respondWithResult(res)).catch(handleError(res));
}

function deleteBid(req, res) {
  // Pulls all bids for a particular lot
  return _user2.default.update({ "_id": req.params.id }, { $pull: { "bids": { "lot_id": req.params.lotid } } }).exec().then(handleEntityNotFound(res)).then(respondWithResult(res)).catch(handleError(res));
}

function addWatch(req, res) {
  return _user2.default.update({ "_id": req.params.id }, { $addToSet: { "watching": req.body } }).exec().then(handleEntityNotFound(res)).then(respondWithResult(res)).catch(handleError(res));
}

function deleteWatch(req, res) {
  return _user2.default.update({ "_id": req.params.id }, { $pull: { "watching": { "lot_id": req.params.lotid } } }).exec().then(handleEntityNotFound(res)).then(respondWithResult(res)).catch(handleError(res));
}

function getBids(req, res, next) {
  return _user2.default.findById(req.params.id).select('bids').exec().then(handleEntityNotFound(res)).then(respondWithResult(res)).catch(handleError(res));
}

function getWatches(req, res, next) {
  return _user2.default.findById(req.params.id).select('watching').exec().then(handleEntityNotFound(res)).then(respondWithResult(res)).catch(handleError(res));
}

function getMessages(req, res, next) {
  var userId = req.params.id;

  return _user2.default.findById(req.params.id).select('messages').exec().then(handleEntityNotFound(res)).then(respondWithResult(res)).catch(handleError(res));
}

function addMessage(req, res) {
  return _user2.default.update({ "_id": req.params.id }, { $push: { "messages": req.body } }).exec().then(handleEntityNotFound(res)).then(respondWithResult(res)).catch(handleError(res));
}

function updateMessage(req, res) {
  return _user2.default.update({ "_id": req.params.id, 'messages': { $elemMatch: { "_id": req.body._id } } }, { $set: { 'messages.$.status': req.body.status } }).exec().then(handleEntityNotFound(res)).then(respondWithResult(res)).catch(handleError(res));
}

function deleteMessage(req, res) {
  return _user2.default.update({ "_id": req.params.id }, { $pull: { "messages": { "_id": req.params.msgid } } }).exec().then(handleEntityNotFound(res)).then(respondWithResult(res)).catch(handleError(res));
}

// Change a lot status
function changestatus(req, res) {
  return _user2.default.findById(req.params.id).exec().then(handleEntityNotFound(res)).then(doStatusChange(req.body)).then(respondWithResult(res)).catch(handleError(res));
}

/**
 * Authentication callback
 */
function authCallback(req, res, next) {
  res.redirect('/');
}
//# sourceMappingURL=user.controller.js.map
