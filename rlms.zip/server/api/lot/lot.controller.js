/**
 * Using Rails-like standard naming convention for endpoints.
 * GET     /api/lots              ->  index
 * POST    /api/lots              ->  create
 * GET     /api/lots/:id          ->  show
 * PUT     /api/lots/:id          ->  update
 * DELETE  /api/lots/:id          ->  destroy
 */

'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getBids = getBids;
exports.index = index;
exports.sortedIndex = sortedIndex;
exports.lotsApproval = lotsApproval;
exports.lotsClosing = lotsClosing;
exports.lotsClosed = lotsClosed;
exports.show = show;
exports.create = create;
exports.addBid = addBid;
exports.deleteBid = deleteBid;
exports.getWatches = getWatches;
exports.addWatch = addWatch;
exports.deleteWatch = deleteWatch;
exports.update = update;
exports.changestatus = changestatus;
exports.destroy = destroy;

var _lodash = require('lodash');

var _lodash2 = _interopRequireDefault(_lodash);

var _lot = require('./lot.model');

var _lot2 = _interopRequireDefault(_lot);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function respondWithResult(res, statusCode) {
  statusCode = statusCode || 200;
  return function (entity) {
    if (entity) {
      return res.status(statusCode).json(entity);
    }
  };
}

function saveUpdates(updates) {
  return function (entity) {
    // Having trouble with merging the nested animal objects.  They all live in the updates entity, so I
    // am going to remove them from the entity first before doing our merge.
    delete entity._doc.animals;
    delete entity._doc.photos;
    var updated = _lodash2.default.merge(entity, updates);
    return updated.save().then(function (updated) {
      return updated;
    });
  };
}

function doStatusChange(updates) {
  return function (entity) {
    entity.status = updates.status;
    return entity.save().then(function (entity) {
      return entity;
    });
  };
}

function getBids(req, res, next) {
  return User.findById(req.params.id).select('bids').exec().then(handleEntityNotFound(res)).then(respondWithResult(res)).catch(handleError(res));
}

function removeEntity(res) {
  return function (entity) {
    if (entity) {
      return entity.remove().then(function () {
        res.status(204).end();
      });
    }
  };
}

function handleEntityNotFound(res) {
  return function (entity) {
    if (!entity) {
      res.status(404).end();
      return null;
    }
    return entity;
  };
}

function handleError(res, statusCode) {
  statusCode = statusCode || 500;
  return function (err) {
    res.status(statusCode).send(err);
  };
}

// Gets a list of Lots
function index(req, res) {
  var query = {};
  if (req.body.onlyOpen != null) {
    var criteria = "status";
    query[criteria] = "Open";
  }
  return _lot2.default.find(query).select('lot_name seller desc quantity close_date category livestock_type photos current_bid status district avg_weight top_weight bottom_weight').sort('-close_date').exec().then(respondWithResult(res)).catch(handleError(res));
}

function sortedIndex(req, res) {
  var query = {};
  if (req.body.onlyOpen != null) {
    var criteria = "status";
    query[criteria] = "Open";
  }
  /*if (req.body.search != null){
   var searchString = req.body.search;
   var dbSearch = "$or";
   query[dbSearch] = "[{'lot_name':{'$regex':"+searchString+", '$options':'i'}},{'desc':{'$regex':"+searchString+", '$options':'i'}},{'seller':{'$regex':"+searchString+", '$options':'i'}},{'category':{'$regex':"+searchString+", '$options':'i'}},{'livestock_type':{'$regex':"+searchString+", '$options':'i'}}]";
    }*/
  if (req.body.livestockType != null) {
    var livestock = "livestock_type";
    query[livestock] = req.body.livestockType;
  }

  if (req.body.status != null) {
    var selectStatus = "status";
    query[selectStatus] = req.body.status;
  }

  if (req.body.search != null) {
    var searchString = req.body.search;
    return _lot2.default.find(query).find({ '$or': [{ 'lot_name': { '$regex': searchString, '$options': 'i' } }, { 'desc': { '$regex': searchString, '$options': 'i' } }, { 'seller': { '$regex': searchString, '$options': 'i' } }, { 'category': { '$regex': searchString, '$options': 'i' } }, { 'livestock_type': { '$regex': searchString, '$options': 'i' } }] }).select('lot_name seller desc quantity close_date category livestock_type photos current_bid status').sort('-close_date').exec().then(respondWithResult(res)).catch(handleError(res));
  } else {

    return _lot2.default.find(query).select('lot_name seller desc quantity close_date category livestock_type photos current_bid status district avg_weight top_weight bottom_weight').sort('-close_date').exec().then(respondWithResult(res)).catch(handleError(res));
  }
}

// Gets a list of Lots needing approval
function lotsApproval(req, res) {
  return _lot2.default.find({ 'status': 'Waiting' }).exec().then(respondWithResult(res)).catch(handleError(res));
}

// Gets a list of Lots needing approval
function lotsClosing(req, res) {
  var today = new Date();
  var tomorrow = new Date();
  tomorrow.setDate(today.getDate() + 3);
  return _lot2.default.find({ 'status': 'Open', 'close_date': {
      $gte: today,
      $lt: tomorrow
    } }).exec().then(respondWithResult(res)).catch(handleError(res));
}

// Gets a list of Lots needing approval
function lotsClosed(req, res) {
  var today = new Date();
  var yesterday = new Date();
  yesterday.setDate(today.getDate() - 3);
  return _lot2.default.find({ 'status': 'Closed', 'close_date': {
      $gte: yesterday,
      $lt: today
    } }).exec().then(respondWithResult(res)).catch(handleError(res));
}

// Gets a single Lot from the DB
function show(req, res) {
  return _lot2.default.findById(req.params.id).exec().then(handleEntityNotFound(res)).then(respondWithResult(res)).catch(handleError(res));
}

// Creates a new Lot in the DB
function create(req, res) {
  return _lot2.default.create(req.body).then(respondWithResult(res, 201)).catch(handleError(res));
}

function addBid(req, res) {
  return _lot2.default.update({ "_id": req.params.id, "current_bid": { $lt: req.body.bid_amount } }, { $addToSet: { "bids": req.body }, $set: { "current_bid": req.body.bid_amount } }).exec().then(handleEntityNotFound(res)).then(respondWithResult(res)).catch(handleError(res));
}

function deleteBid(req, res) {
  return _lot2.default.update({ "_id": req.params.id }, { $pull: { "bids": { "user_id": req.params.userid } } }).exec().then(handleEntityNotFound(res)).then(respondWithResult(res)).catch(handleError(res));
}

function getWatches(req, res, next) {
  return _lot2.default.findById(req.params.id).select('watching').exec().then(handleEntityNotFound(res)).then(respondWithResult(res)).catch(handleError(res));
}

function addWatch(req, res) {
  return _lot2.default.update({ "_id": req.params.id }, { $addToSet: { "watching": req.body } }).exec().then(handleEntityNotFound(res)).then(respondWithResult(res)).catch(handleError(res));
}

function deleteWatch(req, res) {
  return _lot2.default.update({ "_id": req.params.id }, { $pull: { "watching": { "user_id": req.params.userid } } }).exec().then(handleEntityNotFound(res)).then(respondWithResult(res)).catch(handleError(res));
}

// Updates an existing Lot in the DB
function update(req, res) {
  if (req.body._id) {
    delete req.body._id;
  }
  return _lot2.default.findById(req.params.id).exec().then(handleEntityNotFound(res)).then(saveUpdates(req.body)).then(respondWithResult(res)).catch(handleError(res));
}

// Change a lot status
function changestatus(req, res) {
  return _lot2.default.findById(req.params.id).exec().then(handleEntityNotFound(res)).then(doStatusChange(req.body)).then(respondWithResult(res)).catch(handleError(res));
}

// Deletes a Lot from the DB
function destroy(req, res) {
  return _lot2.default.findById(req.params.id).exec().then(handleEntityNotFound(res)).then(removeEntity(res)).catch(handleError(res));
}
//# sourceMappingURL=lot.controller.js.map
