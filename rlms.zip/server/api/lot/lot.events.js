/**
 * Lot model events
 */

'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _events = require('events');

var _lot = require('./lot.model');

var _lot2 = _interopRequireDefault(_lot);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var LotEvents = new _events.EventEmitter();

// Set max event listeners (0 == unlimited)
LotEvents.setMaxListeners(0);

// Model events
var events = {
  save: 'save',
  remove: 'remove'
};

// Register the event emitter to the model events
for (var e in events) {
  var event = events[e];
  _lot2.default.schema.post(e, emitEvent(event));
}

function emitEvent(event) {
  return function (doc) {
    LotEvents.emit(event + ':' + doc._id, doc);
    LotEvents.emit(event, doc);
  };
}

exports.default = LotEvents;
//# sourceMappingURL=lot.events.js.map
