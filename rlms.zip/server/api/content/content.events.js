/**
 * Content model events
 */

'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _events = require('events');

var _content = require('./content.model');

var _content2 = _interopRequireDefault(_content);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var ContentEvents = new _events.EventEmitter();

// Set max event listeners (0 == unlimited)
ContentEvents.setMaxListeners(0);

// Model events
var events = {
  save: 'save',
  remove: 'remove'
};

// Register the event emitter to the model events
for (var e in events) {
  var event = events[e];
  _content2.default.schema.post(e, emitEvent(event));
}

function emitEvent(event) {
  return function (doc) {
    ContentEvents.emit(event + ':' + doc._id, doc);
    ContentEvents.emit(event, doc);
  };
}

exports.default = ContentEvents;
//# sourceMappingURL=content.events.js.map
