'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.setup = setup;

var _passport = require('passport');

var _passport2 = _interopRequireDefault(_passport);

var _passportLocal = require('passport-local');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function localAuthenticate(User, username, password, done) {
  console.log("localAuthenticate. Username:" + username);
  User.findOne({
    username: username
  }).exec().then(function (user) {
    if (!user) {
      return done(null, false, {
        message: 'This username is not registered.'
      });
    }
    user.authenticate(password, function (authError, authenticated) {
      if (authError) {
        return done(authError);
      }
      if (!authenticated) {
        return done(null, false, { message: 'This password is not correct.' });
      } else {
        return done(null, user);
      }
    });
  }).catch(function (err) {
    return done(err);
  });
}

function setup(User /*, config*/) {
  _passport2.default.use(new _passportLocal.Strategy({
    usernameField: 'username',
    passwordField: 'password' // this is the virtual field on the model
  }, function (username, password, done) {
    return localAuthenticate(User, username, password, done);
  }));
}
//# sourceMappingURL=passport.js.map
